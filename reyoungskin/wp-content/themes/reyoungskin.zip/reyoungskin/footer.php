<?php
/**
 * Theme footer template.
 *
 * @package TailPress
 */
?>
</main>

<?php do_action('tailpress_content_end'); ?>
</div>

<?php do_action('tailpress_content_after'); ?>

<footer id="colophon"
    class="w-full bg-primary flex items-center justify-center min-h-[420px] md:min-h-[480px] lg:min-h-[520px]"
    role="contentinfo">
    <div class="text-center">
        <h2 class="font-serif text-white text-5xl md:text-6xl lg:text-7xl font-normal mb-8 md:mb-10 lg:mb-12" 
            data-anim="fade-up">
            Social
        </h2>

        <div class="flex items-center justify-center gap-16 md:gap-20 lg:gap-24" data-anim="stagger" data-anim-stagger="80">
            <a href="https://www.facebook.com/profile.php?id=61582669332322" target="_blank" rel="noopener noreferrer"
                class="social-icon text-white focus:outline-none focus:ring-4 focus:ring-white/50 rounded-lg"
                aria-label="Visit our Facebook page" data-anim-child>
                <svg class="w-20 h-20 md:w-24 md:h-24" fill="currentColor" viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
            </a>

            <a href="https://www.instagram.com/reyoung__skin" target="_blank" rel="noopener noreferrer"
                class="social-icon text-white focus:outline-none focus:ring-4 focus:ring-white/50 rounded-lg"
                aria-label="Visit our Instagram page" data-anim-child>
                <svg class="w-20 h-20 md:w-24 md:h-24" fill="currentColor" viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
            </a>

        </div>

        <!-- Copyright -->
        <div class="mt-12 md:mt-16 lg:mt-20 pt-8 border-t border-white/20" data-anim="fade-up" data-anim-delay="400">
            <p class="text-white/70 text-sm md:text-base font-light tracking-wide">
                &copy; <?php echo date('Y'); ?> ReYoungSkin. All rights reserved.
            </p>
        </div>

    </div>
</footer>
</div>

<?php wp_footer(); ?>
</body>

</html>