<?php

/**
 * Theme header template.
 *
 * @package TailPress
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon"
        href="<?php echo esc_url(get_template_directory_uri() . '/resources/image/favicon/favicon.ico'); ?>">
    <?php wp_head(); ?>
</head>

<body <?php body_class('bg-white text-primary antialiased font-sans'); ?>>
    <?php do_action('tailpress_site_before'); ?>

    <div id="page" class="min-h-screen flex flex-col">
        <?php do_action('tailpress_header'); ?>

        <header class="sticky top-0 z-50 bg-primary text-white h-18 md:h-24">
            <div class="container mx-auto px-4 h-full">
                <div class="flex justify-between font-serif items-center h-full">
                    <nav class="hidden md:flex items-center gap-10">
                        <a href="<?php echo esc_url(home_url('/')); ?>"
                            style=" font-weight: 400; font-style: normal; color: rgb(255, 255, 255); font-kerning: normal; text-decoration-line: none; text-decoration-thickness: initial; text-decoration-style: initial;"
                            class="text-white hover:text-white/80 font-thin text-3xl transition-colors !no-underline">
                            Home
                        </a>
                        <a href="<?php echo esc_url(home_url('/pricing')); ?>"
                            class="text-white hover:text-white/80 font-thin text-3xl transition-colors !no-underline">
                            Pricing
                        </a>
                        <a href="<?php echo esc_url(home_url('/gallery')); ?>"
                            class="text-white hover:text-white/80 font-thin text-3xl transition-colors !no-underline">
                            Gallery
                        </a>
                        <a href="#contact"
                            class="text-white hover:text-white/80 font-thin text-3xl transition-colors !no-underline">
                            Contact Us
                        </a>
                    </nav>

                    <div class="hidden md:flex items-center gap-4">
                        <a href="<?php echo esc_url(get_theme_mod('reyoungskin_instagram', 'https://www.instagram.com/reyoung__skin')); ?>" target="_blank" rel="noopener noreferrer"
                            class="social-icon text-white hover:text-white/80 transition-colors" aria-label="Instagram">
                            <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                            </svg>
                        </a>
                        <a href="<?php echo esc_url(get_theme_mod('reyoungskin_facebook', 'https://www.facebook.com/profile.php?id=61582669332322')); ?>" target="_blank" rel="noopener noreferrer"
                            class="social-icon text-white hover:text-white/80 transition-colors" aria-label="Facebook">
                            <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                            </svg>
                        </a>
                    </div>

                    <!-- Mobile Menu Toggle -->
                    <div class="md:hidden">
                        <button type="button" aria-label="Toggle navigation" id="primary-menu-toggle"
                            class="text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-8 h-8">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Mobile Navigation -->
                <div id="primary-navigation"
                    class="hidden bg-primary p-4 md:hidden pb-4 border-t border-white/20 pt-4 -mx-4">
                    <nav class="flex flex-col gap-4">
                        <a href="<?php echo esc_url(home_url('/')); ?>"
                            class="text-white hover:text-white/80 font-medium text-lg transition-colors !no-underline">
                            Home
                        </a>
                        <a href="<?php echo esc_url(home_url('/pricing')); ?>"
                            class="text-white hover:text-white/80 font-medium text-lg transition-colors !no-underline">
                            Pricing
                        </a>
                        <a href="<?php echo esc_url(home_url('/gallery')); ?>"
                            class="text-white hover:text-white/80 font-medium text-lg transition-colors !no-underline">
                            Gallery
                        </a>
                        <a href="#contact"
                            class="text-white hover:text-white/80 font-medium text-lg transition-colors !no-underline">
                            Contact Us
                        </a>
                    </nav>
                    <div class="flex items-center gap-4 mt-4">
                        <a href="<?php echo esc_url(get_theme_mod('reyoungskin_instagram', 'https://www.instagram.com/reyoung__skin')); ?>" target="_blank" rel="noopener noreferrer"
                            class="social-icon text-white hover:text-white/80 transition-colors" aria-label="Instagram">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                            </svg>
                        </a>
                        <a href="<?php echo esc_url(get_theme_mod('reyoungskin_facebook', 'https://www.facebook.com/profile.php?id=61582669332322')); ?>" target="_blank"
                            rel="noopener noreferrer"
                            class="social-icon text-white hover:text-white/80 transition-colors" aria-label="Facebook">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </header>



        <div id="content" class="site-content grow">
            <?php
            // Display sections on front page
            if (is_front_page()) {
                get_template_part('template-parts/hero-section');
                get_template_part('template-parts/about-section');
                get_template_part('template-parts/services-section');
                get_template_part('template-parts/testimonials-section');
                get_template_part('template-parts/banner-section');
                get_template_part('template-parts/contact-section');
                get_template_part('template-parts/footer-contact-section');
            }
            ?>
            <main>